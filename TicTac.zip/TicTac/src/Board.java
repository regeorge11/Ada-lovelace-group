import java.util.Scanner;
public class Board {
    int i,j;
    //ANSI_Colors ansi_colors = new ANSI_Colors();
    private char[][] playerSpace = {{'*','*','*'},{'*','*','*'},{'*','*','*'}};
    private int[] labels = {1,2,3,4,5,6,7,8,9};
    Scanner input = new Scanner(System.in);

    private void labeledVerticalBoarder(int segments, boolean newline){
        for (int i = 0; i < 3; i++) {
            System.out.printf("| %d ", labels[i + segments * 3]);
        }
        if (newline = true) System.out.println ("|");
    }
    private void spacedVerticalBoarder(int segments, boolean newline){
        for (int i = 0; i < 3; i++) {

            System.out.printf("| %c ", playerSpace[segments][i]);
        }
        if (newline = true) System.out.println ("|");
    }
    private void horizontalBoarder(){
        System.out.println("--------------");
    }
    public void printBoard() {
        labeledVerticalBoarder(0,true);
        spacedVerticalBoarder(0,true);
        horizontalBoarder();
        labeledVerticalBoarder(1,true);
        spacedVerticalBoarder(1,true);
        horizontalBoarder();
        labeledVerticalBoarder(2,true);
        spacedVerticalBoarder(2,false);
    }

    public void placePiece(char piece, int pos) {
        switch(pos) {
            case 1:
                playerSpace [0] [0] = piece ;
                break;
            case 2:
                playerSpace [0] [1] = piece ;
                break;
            case 3:
                playerSpace [0] [2] = piece ;
                break;
            case 4:
                playerSpace [1] [0] = piece ;
                break;
            case 5:
                playerSpace [1] [1] = piece ;
                break;
            case 6:
                playerSpace [1] [2] = piece ;
                break;
            case 7:
                playerSpace [2] [0] = piece ;
                break;
            case 8:
                playerSpace [2] [1] = piece ;
                break;
            case 9:
                playerSpace [2] [2] = piece ;
                break;

        }
    }

    public void clearBoard() {  //uses left right (i), and up down (j)
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                playerSpace [i] [j] = '*';
            }
        }
    }

    public char checkBoard(int pos){
        switch(pos) {
            case 1:
                return playerSpace [0] [0] ;
            case 2:
                return playerSpace [0] [1] ;
            case 3:
                return playerSpace [0] [2] ;
            case 4:
                return playerSpace [1] [0] ;
            case 5:
                return playerSpace [1] [1] ;
            case 6:
                return playerSpace [1] [2] ;
            case 7:
                return playerSpace [2] [0] ;
            case 8:
                return playerSpace [2] [1] ;
            case 9:
                return playerSpace [2] [2] ;

        }
        return ' ';
    }

    public boolean isFull() {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                if (playerSpace [i] [j] == '*') {
                    return false;
                }

            }
        }
        return true;
    }
}
