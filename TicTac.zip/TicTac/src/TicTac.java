import java.util.Scanner;
import java.util.Random;
public class TicTac {
    private Board board = new Board();

    public Board getBoard() {
        return board;
    }
    public static void main(String[] args) {
        TicTac tictac = new TicTac();
        System.out.print("Welcome to tic-tac-toe!\nWhat is player 1's name? ");
        String playerX = "", playerO = "";
        Scanner scanner = new Scanner(System.in);
        String name1;
        name1 = scanner.nextLine();
        System.out.println("Hello, " + name1 + "!\nWhat is player 2's name? ");
        String name2;
        name2 = scanner.nextLine();
        char choice = 'N';
        int xwins = 0, owins = 0, ties = 0, games = 0;
        do {
        System.out.println("Hello, " + name2 + "!\nWho will going first?\n" +
        "1- Player 1\n2- Player 2\n0- I'll choose for you");
        Integer goingFirst;
        goingFirst = scanner.nextInt();
        if (goingFirst == 1){
        System.out.print(name1 + " will be going first.");
        playerX = name1;
        playerO = name2;
        }
        if (goingFirst == 2){
        System.out.print(name2 + " will be going first.");
        playerX = name2;
        playerO = name1;
        }
        if (goingFirst == 0) {
        int chosen;
        Random random = new Random();
        chosen = random.nextInt(2);
        if (chosen == 0) {
        System.out.println("I have chosen " + name1 + " to go first.");
        playerX = name1;
        playerO = name2;
        }
        if (chosen == 1) {
        System.out.println("I have chosen " + name2 + " to go first.");
        playerX = name2;
        playerO = name1;
        }
        }
        System.out.println("\nPlayer 1 is X's\nPlayer 2 is O's\nlets get started!");
        tictac.getBoard().printBoard();
        char winningPiece = tictac.gameLoop(playerX, playerO);
        if (winningPiece == 'X') {
        xwins++;
        } else if (winningPiece == 'O') {
        owins++;
        } else {
        ties++;
        }
        games++;
        tictac.getBoard().clearBoard();
        System.out.println("you have played " + games + " game" + (games == 1? ", " : "s ") + "with " + xwins +
        " win" + (xwins == 1? " " : "s " ) + ("for X, ") + owins + " win" + (owins == 1? " " : "s ") + "for O, " +
                "and " + ties + " tie" + (ties == 1? ". " : "s "));
        System.out.print("Play again? Y/N ");
        Scanner input = new Scanner(System.in);
        choice = input.next().toUpperCase().charAt(0);
        } while (choice == 'Y');
    }


    public char gameLoop (String playerX, String playerO) {
        boolean done = false;
        String currentPlayer = playerX;
        char currentPiece = 'X';
        do {
        int pos = 0;
        do {
        Scanner scan = new Scanner(System.in);
        System.out.println( currentPlayer + " enter your box, 1-9: ");
        pos = scan.nextInt();
        if (pos < 1 || pos > 9){
        System.out.println("nice try, but no. 1 through 9 please.");
        pos = 0;
        }
        if (board.checkBoard(pos) != '*') {
        System.out.println("that space is taken, please choose a * space");
        pos = 0;
        }
        } while (pos == 0);
        board.placePiece(currentPiece, pos);
        board.printBoard();
        if (checkWin(board, currentPiece)) {
        System.out.println(currentPlayer + " has won!");
        done = true;
        } else if (board.isFull()) {
        System.out.println("it's a tie.");
        currentPiece = '*';
        done = true;
        }
        if (done) {
        break;
        }
        currentPlayer = playerO;
        currentPiece = 'O';
        pos = 0;
        do {
        Scanner scan = new Scanner(System.in);
        System.out.println( currentPlayer + " enter your box, 1-9: ");
        pos = scan.nextInt();
        if (pos < 1 || pos > 9){
        System.out.println("nice try, but no. 1 through 9 please.");
        pos = 0;
        }
        if (board.checkBoard(pos) != '*') {
        System.out.println("that space is taken, please choose a * space");
        pos = 0;
        }
        } while (pos == 0);
        board.placePiece(currentPiece, pos);
        board.printBoard();
        if (checkWin(board, currentPiece)) {
        System.out.println(currentPlayer + " has won!");
        done = true;
        } else if (board.isFull()) {
        System.out.println("it's a tie.");
        currentPiece = '*';
        done = true;
        }
        currentPlayer = playerX;
        currentPiece = 'X';

        } while (!done);
        return currentPiece;
        }



    public boolean checkWin(Board board, char currentPiece) {
        if (((board.checkBoard (1) == currentPiece) && (board.checkBoard (2) == currentPiece) && (board.checkBoard (3) == currentPiece)) ||
        ((board.checkBoard (4) == currentPiece) && (board.checkBoard (5) == currentPiece) && (board.checkBoard (6) == currentPiece)) ||
        ((board.checkBoard (7) == currentPiece) && (board.checkBoard (8) == currentPiece) && (board.checkBoard (9) == currentPiece)) ||
        ((board.checkBoard (1) == currentPiece) && (board.checkBoard (4) == currentPiece) && (board.checkBoard (7) == currentPiece)) ||
        ((board.checkBoard (2) == currentPiece) && (board.checkBoard (5) == currentPiece) && (board.checkBoard (8) == currentPiece)) ||
        ((board.checkBoard (3) == currentPiece) && (board.checkBoard (6) == currentPiece) && (board.checkBoard (9) == currentPiece)) ||
        ((board.checkBoard (1) == currentPiece) && (board.checkBoard (5) == currentPiece) && (board.checkBoard (9) == currentPiece)) ||
        ((board.checkBoard (7) == currentPiece) && (board.checkBoard (5) == currentPiece) && (board.checkBoard (3) == currentPiece))) {
        return true;
        } else {
        return false;
        }
    }
}