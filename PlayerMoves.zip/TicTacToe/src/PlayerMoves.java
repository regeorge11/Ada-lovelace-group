/* Player Moves information
 * Jocelyn Richards
 * 30 April 2021
 */

import java.util.Scanner;

public class PlayerMoves {
    public static void main(String[] args) {
        Board board = new Board();

        Player[] players = new Player[2];
        int current;
        Scanner input = new Scanner(System.in);
        board.printBoard();
        System.out.print("Welcome to Tic Tac Toe! \n Player One's name: ");
        players[0] = new Player(input.nextLine());
        System.out.print("Player Two's name: ");
        players[1] = new Player(input.nextLine());
        System.out.println("Welcome " + players[0].getName() + " and " + players[1].getName()
                + ". Please enjoy your game!");
        current = 0;
        boolean loop = true;
        do {
            System.out.println("Time for " + players[current].getName() + " to make a move.");
            break;
        } while(loop);
    }
}
